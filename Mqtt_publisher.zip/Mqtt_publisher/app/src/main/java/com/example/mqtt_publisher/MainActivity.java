package com.example.mqtt_publisher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;

import java.security.cert.PKIXRevocationChecker;


public class MainActivity extends AppCompatActivity {
    MqttClient client;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText topic_txt = findViewById(R.id.topic_text);
        EditText msg_txt = findViewById(R.id.msg_text);
        Button btn = findViewById(R.id.publish_btn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String topic = topic_txt.getText().toString();
                String msg = msg_txt.getText().toString();

                if (isConnected()){
                    try {
                        client = new MqttClient("tcp://quantanics.in:1883",MqttClient.generateClientId(),new MemoryPersistence());
                        MqttConnectOptions options  = new MqttConnectOptions();
                        options.setUserName("quantanics");
                        options.setPassword("quantanics123".toCharArray());


                        client.connect(options);
                        Toast.makeText(MainActivity.this, "Mqtt is connected!!", Toast.LENGTH_SHORT).show();
                        try {
                            client.publish(topic,new MqttMessage(msg.getBytes()));
                            Toast.makeText(MainActivity.this, "Message Published", Toast.LENGTH_SHORT).show();

                        }catch (MqttException e){
                            Log.d("MainActivity","Error publishing message");
                            Toast.makeText(MainActivity.this, "Message not Published", Toast.LENGTH_SHORT).show();
                        }
                    } catch (MqttException e) {
                        e.printStackTrace();
                        Toast.makeText(getBaseContext(),"failed to create mqtt client",Toast.LENGTH_LONG).show();

                    }

                }else{
                    Toast.makeText(getBaseContext(),"please connection internet connections",Toast.LENGTH_LONG).show();
                }
            }
        });


    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mobileData = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return (wifi != null && wifi.isConnected()) || (mobileData != null && mobileData.isConnected());
    }
}